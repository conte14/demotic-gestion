<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Pins/index.html.twig */
class __TwigTemplate_c9b34dc63f93fbfd2ea9b1a15c376f438933a45c4c8886df440472bb31c7442d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Pins/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "Pins/index.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <h2>les clients</h2>
  

   <h2> <a href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_create");
        echo "\">Ajouter un client</a></h2>

   <!-- <table class=\"table\">-->
      ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["Pins"]) || array_key_exists("Pins", $context) ? $context["Pins"] : (function () { throw new RuntimeError('Variable "Pins" does not exist.', 12, $this->source); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["Pin"]) {
            // line 13
            echo "     <table class=\"table\">
    
      <tr>
         <th scope=\"col\">Nom</th>
         <th scope=\"col\">Prenom</th>
         <th scope=\"col\">Telephone</th>
         <th scope=\"col\">Mail</th>
         <th scope=\"col\">Marque</th>
         <th scope=\"col\">Modele</th>
      </tr>
     
      <tr>
       
         <td scope=\"col\">";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["Pin"], "nom", [], "any", false, false, false, 26), "html", null, true);
            echo "</td>
         <td scope=\"col\">";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["Pin"], "prenom", [], "any", false, false, false, 27), "html", null, true);
            echo "</td>
         <td scope=\"col\">";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["Pin"], "telephone", [], "any", false, false, false, 28), "html", null, true);
            echo "</td>
         <td scope=\"col\">";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["Pin"], "mail", [], "any", false, false, false, 29), "html", null, true);
            echo "</td>
         <td scope=\"col\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["Pin"], "marque", [], "any", false, false, false, 30), "html", null, true);
            echo "</td>
         <td scope=\"col\">";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["Pin"], "modele", [], "any", false, false, false, 31), "html", null, true);
            echo "</td>
      </tr>
      </table>

    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 36
            echo "    <p>veuiller ajouter un client</p>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['Pin'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Pins/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 38,  121 => 36,  111 => 31,  107 => 30,  103 => 29,  99 => 28,  95 => 27,  91 => 26,  76 => 13,  71 => 12,  65 => 9,  59 => 5,  52 => 4,  35 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("
 {%  extends 'base.html.twig' %}

 {%  block body %}

    <h2>les clients</h2>
  

   <h2> <a href=\"{{path('app_create')}}\">Ajouter un client</a></h2>

   <!-- <table class=\"table\">-->
      {% for Pin in  Pins %}
     <table class=\"table\">
    
      <tr>
         <th scope=\"col\">Nom</th>
         <th scope=\"col\">Prenom</th>
         <th scope=\"col\">Telephone</th>
         <th scope=\"col\">Mail</th>
         <th scope=\"col\">Marque</th>
         <th scope=\"col\">Modele</th>
      </tr>
     
      <tr>
       
         <td scope=\"col\">{{Pin.nom}}</td>
         <td scope=\"col\">{{Pin.prenom}}</td>
         <td scope=\"col\">{{Pin.telephone}}</td>
         <td scope=\"col\">{{Pin.mail}}</td>
         <td scope=\"col\">{{Pin.marque}}</td>
         <td scope=\"col\">{{Pin.modele}}</td>
      </tr>
      </table>

    {%  else %}
    <p>veuiller ajouter un client</p>
    {%  endfor %}
    {%  endblock %}
 ", "Pins/index.html.twig", "C:\\wamp64\\www\\gestion\\templates\\Pins\\index.html.twig");
    }
}
